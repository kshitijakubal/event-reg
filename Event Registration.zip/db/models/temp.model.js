
const Temp = sequelize.define("Temp", {

      email: {
        type: DataTypes.STRING,
        allowNull: false
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false
      },
 });
 
 module.exports = { Temp }