
const Otp = sequelize.define("Otp", {
    user_id: {
        type: DataTypes.STRING,
        allowNull: false
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false
      },
      otp: {
        type: DataTypes.NUMBER,
        allowNull: false
      },
 });
 
 module.exports = { Otp }