
const Events_Registration = sequelize.define("Events_Registration", {
    user_id: {
        type: DataTypes.STRING,
        allowNull: false
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false
      },
 });
 
 module.exports = { Events_Registration }