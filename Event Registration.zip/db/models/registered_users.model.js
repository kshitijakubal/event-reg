
const Registered_Users = sequelize.define("Registered_Users", {
  user_id: {
    type: DataTypes.STRING,
    allowNull: false
  },
   name: {
     type: DataTypes.STRING,
     allowNull: false
   },
   grade: {
     type: DataTypes.STRING,
   },
   email: {
    type: DataTypes.DATEONLY,
  },
   phone_no: {
     type: DataTypes.DATEONLY,
   },
   state: {
     type: DataTypes.INTEGER,
   },
   city: {
    type: DataTypes.DATEONLY,
  },
  school_name: {
    type: DataTypes.DATEONLY,
  },
  created_at: {
    type: DataTypes.DATEONLY,
  },
});

module.exports = { Registered_Users }