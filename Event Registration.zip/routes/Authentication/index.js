const express = require("express");
const Router = express.Router();
const { UserLogin } = require("../../controllers/Authentication/userLogin");

Router.post("/authentication/registration")
Router.post("/authentication/login", UserLogin)

module.exports = {Router}