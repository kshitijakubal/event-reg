const { User_Resgitration } = require("../../db/models/registered_users.model");
const { Temp } = require("../../db/models/temp.model");
const { Otp } = require("../../db/models/otp.model");
const { Events_Registration } = require("../../db/models/events_registration.model");
const {uuidv4} = 'uuid';

const jwt = require("jsonwebtoken");

const UserLogin = (req, res) => {
    try {
       
    }
    catch(error){
        res.status(400).json({
            status: "400",
            message:"Error in OTP Verificaion"
        })
    }
}
module.exports = { UserLogin }