const { User_Resgitration } = require("../../db/models/registered_users.model");
const { Temp } = require("../../db/models/temp.model");
const { Otp } = require("../../db/models/otp.model");
const nodeMailer = require("nodemailer")
const sendOtp = (req, res) => {
    try {
        const { email } = req.body;
        const existingEmail = UserRegistration.findOne({email: email});
        console.log("existing: ",existingEmail);
        if(!existingEmail){
            Temp.create(req.body)
            const digits = '0123456789'; 
            let OTP = ''; 
            for (let i = 0; i < 4; i++ ) { 
                OTP += digits[Math.floor(Math.random() * 10)]; 
            }
            Otp.create({
                email: email,
                otp: OTP
            })
            // Sending OTP using nodemailer

            res.status(200).json({
                status: "200",
                message:"OTP sent successfully"
            })
        }
    }
    catch(error){
        res.status(400).json({
            status: "400",
            message:"Error in sending otp"
        })
    }
}
module.exports = {sendOtp}