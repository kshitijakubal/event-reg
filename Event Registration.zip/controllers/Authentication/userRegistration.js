const { User_Resgitration } = require("../../db/models/registered_users.model");
const { Temp } = require("../../db/models/temp.model");
const { Otp } = require("../../db/models/otp.model");
const { Events_Registration } = require("../../db/models/events_registration.model");
const {uuidv4} = 'uuid';
const jwt = require("jsonwebtoken");

const UserRegistration = (req, res) => {
    try {
        const { email, otp } = req.body;
        const checkOtp = OTP.findOne({email: email});
        console.log("existing: ",existingEmail);
        let userId = uuidv4()
        if(checkOtp.otp === otp){
            User_Resgitration.create({user_id: userId,...req.body})
            const regsiteredUserId = UserRegistration.findOne({email: email});
            Events_Registration.create({
                user_id: regsiteredUserId.user_id,
                created_at: new Date()
            })
            const token = jwt.sign(
                { user_id: userId, email },
                process.env.TOKEN_KEY,
                {
                  expiresIn: "2h",
                }
              );
            res.status(200).json({
                status: "200",
                message:"User Registered successfully",
                Token: token
            })
        }
    }
    catch(error){
        res.status(400).json({
            status: "400",
            message:"Error in OTP Verificaion"
        })
    }
}